django.jQuery(document).ready(function(){
        if (django.jQuery('#id_has_serial').is(':checked')) {
                hide_field=false;
          } else {
                var elementSerial = document.getElementsByClassName("form-row field-serial_number");
                var i;
                for (i = 0; i < elementSerial.length; i++) {
                    elementSerial[i].style ="display: none!important";
                }
                hide_field=true;
          }
          django.jQuery("#id_has_serial").click(function(){
              hide_field=!hide_field;
              if (hide_field) {
                    var elementSerial = document.getElementsByClassName("form-row field-serial_number");
                    var i;
                    for (i = 0; i < elementSerial.length; i++) {
                        elementSerial[i].style ="display: none!important";
                    }

              } else {
                   var elementSerial = document.getElementsByClassName("form-row field-serial_number");
                   var i;
                   for (i = 0; i < elementSerial.length; i++) {
                      elementSerial[i].style ="display: block!important";
                   }

              }
          })
      })