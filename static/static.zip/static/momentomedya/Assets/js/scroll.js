// var height = $('header').height();

// $(window).scroll(function() {
//     if($(this).scrollTop() > height){
//         $('nav').addClass('fixed-top');
//         $('nav').addClass('navbar-background-transparent');

//     }else{
//         $('nav').removeClass('fixed-top');
//         $('nav').removeClass('navbar-background-transparent');
//     }
// })